 .Sol file Watershed HRU:58 Subbasin:2 HRU:17 Luse:FRSE Soil: LREW02 Slope: 0-9999 11/27/2018 12:00:00 AM ArcSWAT 2012.10_0.14
 Soil Name: LREW02
 Soil Hydrologic Group: A
 Maximum rooting depth(m) : 2160.00
 Porosity fraction from which anions are excluded: 0.500
 Crack volume potential of soil: 0.500
 Texture 1                : S-S
 Depth                [mm]:     1520.00     2160.00
 Bulk Density Moist [g/cc]:        1.50        1.55
 Ave. AW Incl. Rock Frag  :        0.07        0.05
 Ksat. (est.)      [mm/hr]:      331.20      331.20
 Organic Carbon [weight %]:        0.44        0.15
 Clay           [weight %]:        5.00        3.50
 Silt           [weight %]:        1.40        1.50
 Sand           [weight %]:       93.60       95.00
 Rock Fragments   [vol. %]:        6.00        6.00
 Soil Albedo (Moist)      :        0.30        0.30
 Erosion K                :        0.10        0.10
 Salinity (EC, Form 5)    :        0.00        0.00
 Soil pH                  :        5.30        5.30
 Soil CACO3               :        0.00        0.00
                              
